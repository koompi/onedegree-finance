import { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../lib/api'
import { useAuth } from '../store/auth'
import { haptic } from '../lib/telegram'
import CurrencyInput from '../components/CurrencyInput'

interface Transaction {
  id: string; type: 'income' | 'expense'; amount_cents: number; category_icon: string
  category_name_km: string; category_name: string; category_id?: string
  note: string; account_name: string; account_id?: string; occurred_at: string
}

export default function TransactionList() {
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const { companyId } = useAuth()
  const now = new Date()
  const [month, setMonth] = useState(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`)
  const [search, setSearch] = useState('')
  const [swipedId, setSwipedId] = useState<string | null>(null)
  const [editTx, setEditTx] = useState<Transaction | null>(null)
  const [editAmount, setEditAmount] = useState(0)
  const [editCurrency, setEditCurrency] = useState<'USD' | 'KHR'>('USD')
  const [editNote, setEditNote] = useState('')
  const touchStartX = useRef(0)

  const { data: transactions, isLoading } = useQuery({
    queryKey: ['transactions', companyId, month],
    queryFn: () => api.get(`/companies/${companyId}/transactions?month=${month}&limit=100`).then(r => r.data),
    enabled: !!companyId,
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.delete(`/companies/${companyId}/transactions/${id}`),
    onSuccess: () => {
      haptic.success()
      queryClient.invalidateQueries({ queryKey: ['transactions'] })
      queryClient.invalidateQueries({ queryKey: ['report'] })
      setSwipedId(null)
    },
    onError: () => haptic.error(),
  })

  const editMutation = useMutation({
    mutationFn: () => api.patch(`/companies/${companyId}/transactions/${editTx!.id}`, {
      amount_cents: editAmount,
      currency_input: editCurrency,
      note: editNote || undefined,
    }),
    onSuccess: () => {
      haptic.success()
      queryClient.invalidateQueries({ queryKey: ['transactions'] })
      queryClient.invalidateQueries({ queryKey: ['report'] })
      setEditTx(null)
    },
    onError: () => haptic.error(),
  })

  const filtered = (transactions || []).filter((t: Transaction) => {
    if (!search) return true
    const q = search.toLowerCase()
    return (t.category_name_km || '').toLowerCase().includes(q) ||
      (t.category_name || '').toLowerCase().includes(q) ||
      (t.note || '').toLowerCase().includes(q)
  })

  const grouped: Record<string, Transaction[]> = {}
  filtered.forEach((t: Transaction) => {
    const day = t.occurred_at.slice(0, 10)
    if (!grouped[day]) grouped[day] = []
    grouped[day].push(t)
  })

  const prevMonth = () => {
    const d = new Date(month + '-01'); d.setMonth(d.getMonth() - 1)
    setMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`)
  }
  const nextMonth = () => {
    const d = new Date(month + '-01'); d.setMonth(d.getMonth() + 1)
    setMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`)
  }

  const openEdit = (tx: Transaction) => {
    setEditTx(tx)
    setEditAmount(tx.amount_cents)
    setEditNote(tx.note || '')
    setEditCurrency('USD')
    setSwipedId(null)
  }

  const handleTouchStart = (e: React.TouchEvent) => { touchStartX.current = e.touches[0].clientX }
  const handleTouchEnd = (e: React.TouchEvent, id: string) => {
    const diff = touchStartX.current - e.changedTouches[0].clientX
    if (diff > 60) setSwipedId(id)
    else if (diff < -60) setSwipedId(null)
  }

  return (
    <div className="min-h-screen pb-4">
      <div className="flex items-center p-4">
        <button onClick={() => navigate('/')} className="text-2xl mr-3">&larr;</button>
        <h1 className="text-xl font-bold flex-1">ប្រតិបត្តិការ</h1>
      </div>

      <div className="px-4 mb-3">
        <input
          value={search} onChange={e => setSearch(e.target.value)}
          placeholder="🔍 ស្វែងរកតាមប្រភេទ ឬកំណត់ចំណាំ..."
          className="w-full p-2.5 bg-gray-50 rounded-xl border border-gray-200 text-sm"
        />
      </div>

      <div className="flex items-center justify-between px-4 mb-4">
        <button onClick={prevMonth} className="p-2 text-lg">&larr;</button>
        <span className="font-medium">{month}</span>
        <button onClick={nextMonth} className="p-2 text-lg">&rarr;</button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500" />
        </div>
      ) : Object.keys(grouped).length === 0 ? (
        <p className="text-center text-gray-400 py-12">គ្មានប្រតិបត្តិការ</p>
      ) : (
        Object.entries(grouped).map(([day, txs]) => (
          <div key={day} className="mb-4">
            <p className="px-4 text-xs text-gray-400 mb-1">{day}</p>
            {txs.map(tx => (
              <div key={tx.id} className="relative overflow-hidden"
                onTouchStart={handleTouchStart} onTouchEnd={e => handleTouchEnd(e, tx.id)}>
                <div className={`flex items-center px-4 py-3 bg-white border-b border-gray-50 transition-transform duration-200 ${swipedId === tx.id ? '-translate-x-28' : 'translate-x-0'}`}>
                  <span className="text-2xl mr-3">{tx.category_icon || '💵'}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{tx.category_name_km || tx.category_name || 'ផ្សេងៗ'}</p>
                    {tx.note && <p className="text-xs text-gray-400 truncate">{tx.note}</p>}
                    <p className="text-xs text-gray-300">{tx.account_name}</p>
                  </div>
                  <span className={`font-bold whitespace-nowrap ${tx.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                    {tx.type === 'income' ? '+' : '-'}${(tx.amount_cents / 100).toFixed(2)}
                  </span>
                </div>
                {/* Swipe action buttons */}
                <div className="absolute right-0 top-0 bottom-0 flex">
                  <button onClick={() => openEdit(tx)}
                    className="w-14 bg-blue-500 text-white flex items-center justify-center text-xs font-medium">
                    កែ
                  </button>
                  <button onClick={() => { if (confirm('លុបប្រតិបត្តិការនេះ?')) deleteMutation.mutate(tx.id) }}
                    className="w-14 bg-red-500 text-white flex items-center justify-center text-xs font-medium">
                    លុប
                  </button>
                </div>
              </div>
            ))}
          </div>
        ))
      )}

      {/* Edit Modal */}
      {editTx && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setEditTx(null)}>
          <div className="absolute inset-0 bg-black/40" />
          <div className="relative w-full bg-white rounded-t-2xl p-5 pb-8 space-y-4" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-lg font-bold">កែប្រែប្រតិបត្តិការ</h2>
              <button onClick={() => setEditTx(null)} className="text-gray-400 text-xl">&times;</button>
            </div>
            <div className="text-sm text-gray-500 mb-1">
              {editTx.category_icon} {editTx.category_name_km || editTx.category_name}
              <span className={`ml-2 font-medium ${editTx.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                ({editTx.type === 'income' ? 'ចំណូល' : 'ចំណាយ'})
              </span>
            </div>
            <CurrencyInput value={editAmount} onChange={(cents, cur) => { setEditAmount(cents); setEditCurrency(cur) }} />
            <input value={editNote} onChange={e => setEditNote(e.target.value)}
              placeholder="កំណត់ចំណាំ" className="w-full p-3 border border-gray-200 rounded-xl" />
            <button onClick={() => editMutation.mutate()}
              disabled={!editAmount || editMutation.isPending}
              className="w-full bg-blue-500 text-white py-3 rounded-xl font-medium disabled:opacity-50">
              {editMutation.isPending ? 'កំពុងរក្សាទុក...' : 'រក្សាទុក'}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../lib/api'
import { useAuth } from '../store/auth'
import { tg, haptic } from '../lib/telegram'

export default function Settings() {
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const { companyId, setCompany, logout } = useAuth()
  const [showNewCompany, setShowNewCompany] = useState(false)
  const [newName, setNewName] = useState('')
  const [lang, setLang] = useState(() => localStorage.getItem('lang') || 'km')
  const [currency, setCurrency] = useState(() => localStorage.getItem('currency') || 'USD')
  const [showAddCategory, setShowAddCategory] = useState(false)
  const [catEmoji, setCatEmoji] = useState('')
  const [catName, setCatName] = useState('')
  const [catType, setCatType] = useState<'income' | 'expense'>('expense')
  const [exporting, setExporting] = useState(false)

  const tgUser = (tg as any).initDataUnsafe?.user

  useEffect(() => { localStorage.setItem('lang', lang) }, [lang])
  useEffect(() => { localStorage.setItem('currency', currency) }, [currency])

  const { data: companies } = useQuery({
    queryKey: ['companies'],
    queryFn: () => api.get('/companies').then(r => r.data),
  })

  const { data: categories } = useQuery({
    queryKey: ['categories', companyId],
    queryFn: () => api.get(`/companies/${companyId}/categories`).then(r => r.data),
    enabled: !!companyId,
  })

  const createCompany = useMutation({
    mutationFn: () => api.post('/companies', { name: newName }),
    onSuccess: (res) => {
      haptic.success()
      queryClient.invalidateQueries({ queryKey: ['companies'] })
      setCompany(res.data.id)
      setShowNewCompany(false); setNewName('')
    },
  })

  const deleteCompany = useMutation({
    mutationFn: (id: string) => api.delete(`/companies/${id}`),
    onSuccess: () => {
      haptic.success()
      queryClient.invalidateQueries({ queryKey: ['companies'] })
    },
  })

  const addCategory = useMutation({
    mutationFn: () => api.post(`/companies/${companyId}/categories`, {
      name: catName,
      icon: catEmoji || '📁',
      type: catType,
    }),
    onSuccess: () => {
      haptic.success()
      queryClient.invalidateQueries({ queryKey: ['categories'] })
      setShowAddCategory(false); setCatEmoji(''); setCatName('')
    },
  })

  const deleteCategory = useMutation({
    mutationFn: (id: string) => api.delete(`/companies/${companyId}/categories/${id}`),
    onSuccess: () => {
      haptic.success()
      queryClient.invalidateQueries({ queryKey: ['categories'] })
    },
  })

  const exportData = async () => {
    setExporting(true)
    try {
      const months = []
      const now = new Date()
      for (let i = 0; i < 6; i++) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
        months.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`)
      }
      const reports = await Promise.all(
        months.map(m => api.get(`/companies/${companyId}/reports/monthly?month=${m}`).then(r => ({ month: m, ...r.data })))
      )
      const blob = new Blob([JSON.stringify(reports, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url; a.download = `onedegree-report-${months[0]}.json`; a.click()
      URL.revokeObjectURL(url)
      haptic.success()
    } catch { haptic.error() }
    setExporting(false)
  }

  return (
    <div className="min-h-screen pb-4">
      <div className="flex items-center p-4">
        <button onClick={() => navigate('/')} className="text-2xl mr-3">&larr;</button>
        <h1 className="text-xl font-bold flex-1">ការកំណត់</h1>
      </div>

      <div className="px-4 space-y-4">
        {/* Profile */}
        <div className="bg-white rounded-xl p-4 border border-gray-100">
          <p className="text-xs text-gray-400 mb-2">ព័ត៌មានផ្ទាល់ខ្លួន / Profile</p>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-lg">
              {tgUser?.first_name?.[0] || '👤'}
            </div>
            <div>
              <p className="font-medium">{tgUser?.first_name || ''} {tgUser?.last_name || ''}</p>
              {tgUser?.username && <p className="text-xs text-gray-400">@{tgUser.username}</p>}
            </div>
          </div>
        </div>

        {/* Language */}
        <div className="bg-white rounded-xl p-4 border border-gray-100">
          <p className="text-xs text-gray-400 mb-2">ភាសា / Language</p>
          <div className="flex gap-2">
            <button onClick={() => setLang('km')}
              className={`flex-1 py-2 rounded-xl text-sm font-medium ${lang === 'km' ? 'bg-blue-500 text-white' : 'bg-gray-100'}`}>
              ខ្មែរ
            </button>
            <button onClick={() => setLang('en')}
              className={`flex-1 py-2 rounded-xl text-sm font-medium ${lang === 'en' ? 'bg-blue-500 text-white' : 'bg-gray-100'}`}>
              English
            </button>
          </div>
        </div>

        {/* Currency */}
        <div className="bg-white rounded-xl p-4 border border-gray-100">
          <p className="text-xs text-gray-400 mb-2">រូបិយប័ណ្ណ / Currency</p>
          <div className="flex gap-2">
            <button onClick={() => setCurrency('USD')}
              className={`flex-1 py-2 rounded-xl text-sm font-medium ${currency === 'USD' ? 'bg-green-500 text-white' : 'bg-gray-100'}`}>
              USD ($)
            </button>
            <button onClick={() => setCurrency('KHR')}
              className={`flex-1 py-2 rounded-xl text-sm font-medium ${currency === 'KHR' ? 'bg-green-500 text-white' : 'bg-gray-100'}`}>
              KHR (៛)
            </button>
          </div>
        </div>

        {/* Categories */}
        <div className="bg-white rounded-xl p-4 border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs text-gray-400">ប្រភេទ / Categories</p>
            <button onClick={() => setShowAddCategory(!showAddCategory)} className="text-blue-500 text-sm">+ បន្ថែម</button>
          </div>

          {showAddCategory && (
            <div className="mb-3 space-y-2 p-3 bg-gray-50 rounded-lg">
              <div className="flex gap-2">
                <input value={catEmoji} onChange={e => setCatEmoji(e.target.value)} placeholder="🎯" maxLength={4}
                  className="w-14 p-2 border border-gray-200 rounded-lg text-center text-lg" />
                <input value={catName} onChange={e => setCatName(e.target.value)} placeholder="ឈ្មោះប្រភេទ"
                  className="flex-1 p-2 border border-gray-200 rounded-lg text-sm" />
              </div>
              <div className="flex gap-2">
                <button onClick={() => setCatType('income')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-medium ${catType === 'income' ? 'bg-green-500 text-white' : 'bg-gray-100'}`}>
                  ចំណូល
                </button>
                <button onClick={() => setCatType('expense')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-medium ${catType === 'expense' ? 'bg-red-500 text-white' : 'bg-gray-100'}`}>
                  ចំណាយ
                </button>
              </div>
              <button onClick={() => addCategory.mutate()} disabled={!catName || addCategory.isPending}
                className="w-full bg-blue-500 text-white py-2 rounded-lg text-sm disabled:opacity-50">
                {addCategory.isPending ? 'កំពុងរក្សាទុក...' : 'រក្សាទុក'}
              </button>
            </div>
          )}

          <div className="space-y-1 max-h-48 overflow-y-auto">
            {categories?.map((c: { id: string; name: string; name_km?: string; icon: string; type: string; is_default?: boolean }) => (
              <div key={c.id} className="flex items-center justify-between py-1.5">
                <span className="text-sm">
                  <span className="mr-1">{c.icon}</span>
                  {c.name_km || c.name}
                  <span className={`ml-2 text-xs ${c.type === 'income' ? 'text-green-500' : 'text-red-500'}`}>
                    {c.type === 'income' ? 'ចំណូល' : 'ចំណាយ'}
                  </span>
                </span>
                {!c.is_default && (
                  <button onClick={() => { if (confirm('លុបប្រភេទនេះ?')) deleteCategory.mutate(c.id) }}
                    className="text-red-400 text-xs">លុប</button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Companies */}
        <div className="bg-white rounded-xl p-4 border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs text-gray-400">ក្រុមហ៊ុន / Companies</p>
            <button onClick={() => setShowNewCompany(!showNewCompany)} className="text-blue-500 text-sm">+ បន្ថែម</button>
          </div>

          {showNewCompany && (
            <div className="mb-3 flex gap-2">
              <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="ឈ្មោះក្រុមហ៊ុន"
                className="flex-1 p-2 border border-gray-200 rounded-lg text-sm" />
              <button onClick={() => createCompany.mutate()} disabled={!newName}
                className="bg-blue-500 text-white px-3 py-2 rounded-lg text-sm disabled:opacity-50">រក្សាទុក</button>
            </div>
          )}

          {companies?.map((c: { id: string; name: string; type: string }) => (
            <div key={c.id} className={`flex items-center justify-between py-2 ${companyId === c.id ? 'font-bold' : ''}`}>
              <button onClick={() => setCompany(c.id)} className="text-left flex-1">
                <p className="text-sm">{c.name}</p>
                <p className="text-xs text-gray-400">{c.type}</p>
              </button>
              <button onClick={() => { if (confirm('លុបក្រុមហ៊ុន?')) deleteCompany.mutate(c.id) }}
                className="text-red-400 text-xs">លុប</button>
            </div>
          ))}
        </div>

        {/* Export */}
        <button onClick={exportData} disabled={exporting}
          className="w-full bg-white text-blue-500 py-3 rounded-xl font-medium border border-blue-200 disabled:opacity-50">
          {exporting ? 'កំពុងទាញយក...' : '📥 ទាញយកទិន្នន័យ (6 ខែ) / Export Data'}
        </button>

        {/* Logout */}
        <button onClick={() => { logout(); navigate('/') }}
          className="w-full bg-red-50 text-red-500 py-3 rounded-xl font-medium border border-red-100">
          ចាកចេញ / Logout
        </button>
      </div>
    </div>
  )
}
